create
    definer = root@localhost procedure SHOW_ALL_USER()
BEGIN 
SELECT * FROM USERS;
END;

